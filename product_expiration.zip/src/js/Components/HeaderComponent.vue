<template>
    <header>
        <nav class=" light-blue accent-4">
            <div class="nav-wrapper container ">
                <a href="#" class="brand-logo">PEMS</a>
            </div>
        </nav>
    </header>
</template>

<script>
    export default {
        name:"HeaderComponent",
        data:()=>{
            return {
                msg:"Hello View",
            }
        }
    }
</script>

<style scoped>

</style>