<template>
    
</template>

<script>
    export default {
        name: "ProductForm"
    }
</script>

<style scoped>

</style>