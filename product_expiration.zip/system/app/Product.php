<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 6/29/2018
 * Time: 9:17 AM
 */

namespace App;

use Illuminate\Database\Eloquent\Model;
class Product extends Model
{

}