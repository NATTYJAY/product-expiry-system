<?php
/**
 * Created by PhpStorm.
 * User: USER
 * Date: 7/3/2018
 * Time: 1:57 PM
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Admin extends  Model
{
    protected $table ='admin';
}